import copy
import torch
import torch.nn as nn
import os
import pandas as pd
import math
from torch.nn.functional import normalize
import torch.nn.functional as F
import numpy as np
L2norm = nn.functional.normalize
import random

class FCN(nn.Module):
    def __init__(self, dim_layer=None, norm_layer=None, act_layer=None, drop_out=0.0, norm_last_layer=True):
        super(FCN, self).__init__()
        act_layer = act_layer or nn.ReLU
        norm_layer = norm_layer or nn.BatchNorm1d
        layers = []
        for i in range(1, len(dim_layer) - 1):
            layers.append(nn.Linear(dim_layer[i - 1], dim_layer[i], bias=False))
            layers.append(norm_layer(dim_layer[i]))
            layers.append(act_layer())
            if drop_out != 0.0 and i != len(dim_layer) - 2:
                layers.append(nn.Dropout(drop_out))

        if norm_last_layer:
            layers.append(nn.Linear(dim_layer[-2], dim_layer[-1], bias=False))
            layers.append(nn.BatchNorm1d(dim_layer[-1], affine=False))
        else:
            layers.append(nn.Linear(dim_layer[-2], dim_layer[-1], bias=True))

        self.ffn = nn.Sequential(*layers)

    def forward(self, x):
        return self.ffn(x)


class MLP(nn.Module):
    def __init__(self, dim_in, dim_out=None, hidden_ratio=4.0, act_layer=None):
        super(MLP, self).__init__()
        dim_out = dim_out or dim_in
        dim_hidden = int(dim_in * hidden_ratio)
        act_layer = act_layer or nn.ReLU
        self.mlp = nn.Sequential(nn.Linear(dim_in, dim_hidden),
                                 act_layer(),
                                 nn.Linear(dim_hidden, dim_out))

    def forward(self, x):
        x = self.mlp(x)
        return x


class simpleMetaNet(nn.Module):
    def __init__(self, input_dim=128, hidden_dim=256, output_dim=128, n_views=3, dropout=0.2):
        super(simpleMetaNet, self).__init__()
        self.n_views = n_views
        self.input_dim = input_dim

        # MLP:  [B, V, D] => reshape ? [B, V*D]
        self.mlp = nn.Sequential(
            nn.Linear(n_views * input_dim, hidden_dim),
            # nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim)
        )
    def forward(self, x, v_idx=None):
        # x: [B, V, D] ? [B, V*D]
        x = x.view(x.size(0), -1)
        out = self.mlp(x)  # [B, output_dim]
        return out.unsqueeze(1), None

class AttentionMetaNet(nn.Module):
    def __init__(self, input_dim=128, n_views=3, hidden_dim=256, output_dim=128, dropout=0.2):
        super(AttentionMetaNet, self).__init__()
        self.n_views = n_views
        self.input_dim = input_dim
        self.query_proj = nn.Linear(input_dim, hidden_dim)
        self.key_proj = nn.Linear(input_dim, hidden_dim)
        self.value_proj = nn.Linear(input_dim, output_dim)
        self.scale = hidden_dim ** 0.5
        self.dropout = nn.Dropout(dropout)
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )
    def forward(self, x, attn_mask=None,more=False):
        # x: [B, V, D]
        B, V, _ = x.shape
        Q = self.query_proj(x)  # [B, V, H]
        K = self.key_proj(x)    # [B, V, H]
        V_ = self.value_proj(x)  # [B, V, D_out]
        # Attention score: [B, V, V]
        scores = (Q @ K.transpose(-2, -1)) / 1#self.scale  # raw attention scores
        # Apply attention mask if provided
        if attn_mask is not None:

            mask_row = attn_mask.unsqueeze(1)  # valid attention *to*
            mask_col = attn_mask.unsqueeze(2)  # valid attention *from*
            full_mask = mask_row * mask_col    # [B, V, V]
            scores = scores.masked_fill(full_mask == 0, float(-1e5))

        # Compute attention weights
        attn = torch.softmax(scores, dim=-1)  # [B, V, V]
        attn_view = attn.mean(dim=1, keepdim=True)
        attn = self.dropout(attn)
        # Apply attention to values
        fused = attn @ V_  # [B, V, D_out]
        if attn_mask is not None:
            # attn_mask: [B, V]
            valid_mask = attn_mask.float()

            fused = fused * valid_mask.unsqueeze(-1)  # [B, V, D_out]

            valid_count = valid_mask.sum(dim=1, keepdim=True)  # [B, 1]

            valid_count = valid_count.clamp(min=1)

            fused = fused.sum(dim=1) / valid_count  # [B, D_out]
            fused = fused.unsqueeze(1)  # [B, 1, D_out]
        else:
            fused = fused.mean(dim=1, keepdim=True)  # [B, 1, D_out]
        # Pass through MLP
        fused = self.mlp(fused)  # [B, 1, output_dim]
        return fused,attn_view

class EVE(nn.Module):
    def __init__(self, args, n_views, layer_dims, temperature, n_classes, drop_rate=0.5):
        super(EVE, self).__init__()
        self.n_views = n_views
        self.n_classes = n_classes
        self.args = args
        self.temperature = temperature
        self.scale=0.001
        # Online encoder per view
        self.online_encoder = nn.ModuleList([FCN(layer_dims[i], drop_out=drop_rate) for i in range(self.n_views)])
        self.target_encoder = copy.deepcopy(self.online_encoder)

        for param_q, param_k in zip(self.online_encoder.parameters(), self.target_encoder.parameters()):
            param_k.data.copy_(param_q.data)
            param_k.requires_grad = False

        self.cross_view_decoder = nn.ModuleList(
            [MLP(layer_dims[i][-1], layer_dims[i][-1]) for i in range(self.n_views)])

        self.meta_net = AttentionMetaNet(input_dim=layer_dims[0][-1], output_dim=layer_dims[0][-1],
                                         n_views=self.n_views)

        self.cl = ContrastiveLoss(temperature)
        self.feature_dim = [layer_dims[i][-1] for i in range(self.n_views)]

    def forward(self, data, pseudo_labels, labels, momentum, warm_up, epoch, cluster_centersview=None,batch_indices=None,
                fuse_pseudo_labels=None, batch_mask=None, cluster_centers=None):
        labels = labels.cuda()
        pseudo_labels = [torch.from_numpy(p).to(labels.device) if isinstance(p, np.ndarray) else p.to(labels.device)
                         for p in pseudo_labels]
        self._update_target_branch(momentum)
        self.epoch = epoch
        self.labels = labels
        z = [self.online_encoder[i](data[i]) for i in range(self.n_views)]
        z_t = [self.target_encoder[i](data[i]) for i in range(self.n_views)]
        # Normalize and fuse using MetaNet
        z_norm = [normalize(feat, dim=1) for feat in z]
        z_stack = torch.stack(z_norm, dim=1)  # shape: [B, V, D]

        z_list, attn_view = self.meta_net(z_stack)
        z_fused = z_list.squeeze(1)  # shape: [B, D]

        p = [self.cross_view_decoder[i](z[i]) for i in range(self.n_views)]

        if warm_up:
            mp = [torch.eye(z[i].shape[0], device=z[i].device) for i in range(self.n_views)]
        else:

            mp = [self.kernel_affinity_sinkhorn(z_t[i], z_fused) for i in range(self.n_views)]
        l_intra = 0
        l_inter = 0
        l_fuse = 0
        if 1:
            l_intra = sum(self.cl(p[i], z_t[i], mp[i]) for i in range(self.n_views)) / self.n_views

            loss_mat = []

            for i in range(self.n_views):
                loss_i = self.cl(z_fused, p[i], mp[i], reduce='sample')
                loss_mat.append(loss_i)
                weight_i = torch.tensor(1 / self.n_views)
                l_fuse += (loss_i * weight_i).mean()
            # stack => [V, B]
            loss_mat = -torch.stack(loss_mat, dim=0)
            l_inter = self.compute_cross_view_loss(p, z_t, mp, loss_mat)

        return self.scale * (l_intra + l_inter * float(epoch >= 80) + (1 * l_fuse) * float(epoch >= 50))

    def compute_cross_view_loss(self, p, z_t, mp, sim_mat):
        device = p[0].device
        V = len(p)
        B = p[0].size(0)
        # -------------------------------------------------------
        # 1. dominant view
        # -------------------------------------------------------
        idx_max = sim_mat.argmax(dim=0)  # [B]
        # -------------------------------------------------------
        #  mask_pair build
        # -------------------------------------------------------
        mask_pair = torch.zeros((V, V, B), dtype=torch.bool, device=device)

        # 5.1 dominant edges
        src_idx = torch.arange(V, device=device).view(V, 1).expand(V, B)
        tgt_idx = idx_max.unsqueeze(0).expand(V, B)
        samp_idx = torch.arange(B, device=device).view(1, B).expand(V, B)
        dom_mask = (src_idx != tgt_idx)
        mask_pair[src_idx, tgt_idx, samp_idx] = dom_mask

        total_loss = torch.tensor(0., device=device)
        valid_count = 0.
        for i in range(V):
            for j in range(V):
                if i == j:
                    continue
                loss_ij = self.cl(p[i], z_t[j], mp[j], reduce='sample')
                mask_ij = mask_pair[i, j].float()
                total_loss += (loss_ij * mask_ij).sum()
                valid_count += mask_ij.sum()

        l_inter = total_loss / (valid_count + 1e-8) if valid_count > 0 else torch.tensor(0., device=device)

        return l_inter

    @torch.no_grad()
    def kernel_affinity_sinkhorn(
            self,
            z,
            z_fused=None,
            temperature=0.1,
            step: int = 5,
            alpha: float = 0.5,
            sinkhorn_iters: int = 5,
            eps: float = 1e-8
    ):
        # 1. L2 normalize
        z = F.normalize(z, dim=1)
        if z_fused is not None:
            z_fused = F.normalize(z_fused, dim=1)
            S = z @ z_fused.t()  # [B,B]
        else:
            S = z @ z.t()  # [B,B]

        # 2. RBF-like affinity
        G = (2 - 2 * S).clamp(min=0.)
        W = torch.exp(-G / temperature)  # [B,B]

        # 3. Sinkhorn ? approx doubly stochastic
        for _ in range(sinkhorn_iters):
            W = W / (W.sum(dim=1, keepdim=True) + eps)
            W = W / (W.sum(dim=0, keepdim=True) + eps)

        # 4. High-order diffusion
        P = torch.matrix_power(W, step)

        # 5. Self-loop dominance (still probability)
        I = torch.eye(P.size(0), device=P.device)
        P = alpha * I + (1 - alpha) * P
        P = P / (P.sum(dim=1, keepdim=True) + eps)

        return P

    @torch.no_grad()
    def _update_target_branch(self, momentum):
        for i in range(self.n_views):
            for param_o, param_t in zip(self.online_encoder[i].parameters(), self.target_encoder[i].parameters()):
                param_t.data = param_t.data * momentum + param_o.data * (1 - momentum)

    @torch.no_grad()
    def extract_feature(self, data, mask):

        N = data[0].shape[0]
        z = [torch.zeros(N, self.feature_dim[i]).to(data[0].device) for i in range(self.n_views)]

        for i in range(self.n_views):
            z[i][mask[:, i]] = self.online_encoder[i](data[i][mask[:, i]])

        source_features = [torch.zeros_like(z[i]) for i in range(self.n_views)]
        for i in range(self.n_views):
            missing_idx = ~mask[:, i]
            if missing_idx.sum() == 0:
                continue

            for idx in torch.where(missing_idx)[0]:

                available_views = [j for j in range(self.n_views) if mask[idx, j] and j != i]
                if len(available_views) == 0:
                    continue
                source_view = available_views[0]
                source_features[i][idx] = z[source_view][idx]


        for i in range(self.n_views):
            missing_idx = ~mask[:, i]
            if missing_idx.sum() > 0:

                for idx in torch.where(missing_idx)[0]:

                    available_views = [j for j in range(self.n_views) if mask[idx, j] and j != i]
                    if len(available_views) == 0:
                        continue
                    source_view = random.choice(available_views)
                    z[i][idx] = self.cross_view_decoder[source_view](source_features[i][idx].unsqueeze(0)).squeeze(
                        0)

        z_ori = [L2norm(z[i]) for i in range(self.n_views)]
        z = [self.cross_view_decoder[i](z[i]) for i in range(self.n_views)]
        z = [L2norm(z[i]) for i in range(self.n_views)]
        return z, z_ori

    @torch.no_grad()
    def extract_feature_meta(self, data, mask):
        N = data[0].shape[0]
        z = [torch.zeros(N, self.feature_dim[i]).cuda() for i in range(self.n_views)]
        for i in range(self.n_views):
            z[i][mask[:, i]] = self.online_encoder[i](data[i][mask[:, i]])


        z = [L2norm(z[i]) for i in range(self.n_views)]
        # Normalize and fuse using MetaNet
        z_norm = [normalize(feat, dim=1) for feat in z]
        z_stack = torch.stack(z_norm, dim=1)  # shape: [B, V, D]
        z_fused, _ = self.meta_net(z_stack, mask.cuda())
        z_fused = z_fused.squeeze(1)  # shape: [B, D]

        return z_fused



class ContrastiveLoss(nn.Module):
    def __init__(self, temperature=1.0):
        super(ContrastiveLoss, self).__init__()
        self.temperature = temperature

    def forward(self, x_q, x_k, mask_pos=None, disgree_indices=None, reduce='mean', labels=None, batch_mask=None):
        x_q = L2norm(x_q)
        x_k = L2norm(x_k)
        N = x_q.shape[0]
        B = x_q.size(0)
        if mask_pos is None:
            mask_pos = torch.eye(N).cuda()

        similarity = torch.div(torch.matmul(x_q, x_k.T), self.temperature)
        similarity = -torch.log(torch.softmax(similarity, dim=1))
        nll_loss = (similarity * mask_pos) / mask_pos.sum(dim=1, keepdim=True)

        if reduce == 'sample':
            return nll_loss.sum(dim=1)  # /N  # [B]
        return (nll_loss.sum(dim=1)).mean()  # /N


