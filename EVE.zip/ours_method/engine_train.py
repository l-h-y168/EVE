import math
import sys
from typing import Iterable
import numpy as np
import torch
import pandas as pd
import os
from sklearn.cluster import KMeans
import utils
from utils import adjust_learning_config, SmoothedValue, MetricLogger
import torch_clustering
import torch.nn.functional as F
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import seaborn as sns
from scipy.optimize import linear_sum_assignment
from matplotlib.lines import Line2D
def train_one_epoch(model: torch.nn.Module,
                    data_loader_train: Iterable, data_loader_test: Iterable,
                    optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int,
                    state_logger=None,
                    args=None,
                    pseudo_labels=None):
    metric_logger = MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', SmoothedValue(window_size=1, fmt='{value:.6f}'))
    data_loader = enumerate(data_loader_train)
    c_epoch = args.epochs-10

    eval_result=None
    if epoch>=c_epoch or epoch==0 or args.print_this_epoch:

        eval_result, pseudo_labels,all_result,true_labels,cluster_centersview = evaluate(model, data_loader_test, device, epoch, args)
        try:
            eval_result, pseudo_labels, cluster_centers, feature = evaluate_meta(model, data_loader_test, device,
                                                                                     epoch, args)
        except Exception as e:
            print(f"Fail: {e}")
        pseudo_labels=torch.tensor(pseudo_labels).to(device='cuda', dtype=torch.long)
        #eval_result = None
    model.train(True)
    optimizer.zero_grad()

    for data_iter_step, (ids, samples, mask, labels) in data_loader:
        smooth_epoch = epoch + (data_iter_step + 1) / len(data_loader_train)
        lr = adjust_learning_config(optimizer, smooth_epoch, args)
        mmt = args.momentum
        for i in range(args.n_views):
            samples[i] = samples[i].to(device, non_blocking=True)

        with torch.autocast('cuda', enabled=False):
            if  epoch >= c_epoch or (epoch+1)%args.print_freq == 0 :
                batch_pseudo_labels = [all_result[i][ids] for i in range(len(all_result))]
            else:
                batch_pseudo_labels = [torch.zeros_like(labels) for i in range(args.n_views)]

            loss = model(samples,batch_pseudo_labels,labels, mmt, epoch < args.start_rectify_epoch,epoch)

        loss_value = loss.item()
        if not math.isfinite(loss_value):
            print("Loss is {}, stopping training".format(loss_value))
            sys.exit(1)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        if args.print_this_epoch:
            metric_logger.update(lr=lr)
            metric_logger.update(loss=loss_value)

    if epoch==args.epochs-1:
        print("Averaged stats:", metric_logger)
        eval_result,_, all_result, true_labels,cluster_centersview  = evaluate(model, data_loader_test, device, epoch, args)

        try:
            eval_result, pseudo_labels_att,cluster_centers,feature = evaluate_meta(model, data_loader_test, device, epoch, args)
        except Exception as e:
            print(f"Fail: {e}")

    return eval_result,pseudo_labels


def evaluate(model: torch.nn.Module, data_loader_test: Iterable,
             device: torch.device, epoch: int, args=None):

    model.eval()
    extracter = model.extract_feature

    all_features = [[] for _ in range(args.n_views)]
    all_features_ori = [[] for _ in range(args.n_views)]
    all_labels = []
    all_indexs = []
    all_results=[]
    all_view_metrics = []
    print("evaluate ...")

    with torch.no_grad():
        for indexs, samples, mask, labels in data_loader_test:
            indexs = indexs.cpu()

            all_indexs.append(indexs)
            all_labels.append(labels.cpu())

            for i in range(args.n_views):
                samples[i] = samples[i].to(device, non_blocking=True)

            features,features_ori = extracter(samples, mask)

            for i in range(args.n_views):
                all_features[i].append(features[i].detach().cpu())
                all_features_ori[i].append(features_ori[i].detach().cpu())



    indexs_all = torch.cat(all_indexs, dim=0)
    labels_all = torch.cat(all_labels, dim=0)
    features_all = [torch.cat(view_feat, dim=0) for view_feat in all_features]
    features_all_ori = [torch.cat(view_feat, dim=0) for view_feat in all_features_ori]


    sorted_idx = indexs_all.argsort()
    labels_all = labels_all[sorted_idx]
    features_all = [feat[sorted_idx] for feat in features_all]
    features_all_ori = [feat[sorted_idx] for feat in features_all_ori]


    features_cat = torch.stack(features_all, dim=1).reshape(labels_all.shape[0], -1)
    features_cat = torch.nn.functional.normalize(features_cat, dim=-1)#.cpu().numpy()



    kwargs = {
        'metric': 'cosine',
        'distributed': True,
        'random_state': 0,
        'n_clusters': args.n_classes,
        'verbose': False
    }

    clustering_model = torch_clustering.PyTorchKMeans(init='k-means++', max_iter=300, tol=1e-4, **kwargs)

    kmeans_label = clustering_model.fit_predict(features_cat.cuda()).cpu().numpy()

    kmeans_label_aligned = match_labels(labels_all.numpy(), kmeans_label)
    all_results.append(kmeans_label_aligned)
    from sklearn.metrics import silhouette_score


    true_labels = labels_all.cpu().numpy()


    silhouette_pred = silhouette_score(features_cat, kmeans_label)

    nmi, ari, f, acc = utils.evaluate(labels_all.numpy(), kmeans_label_aligned)
    result = {'nmi': nmi, 'ari': ari, 'f': f, 'acc': acc, 'sc': silhouette_pred }
    print("result:", result)


    print("Evaluate peer view ...")
    view_centers = []
    view_preds_all = []
    view_preds_allp = []
    for view_id, feature_view in enumerate(features_all):
        feature_view = torch.nn.functional.normalize(feature_view, dim=-1)

        clustering_model = torch_clustering.PyTorchKMeans(
            init='k-means++',
            max_iter=300,
            tol=1e-4,
            metric='cosine',
            distributed=True,
            random_state=0,
            n_clusters=args.n_classes,
            verbose=False
        )

        view_pred = clustering_model.fit_predict(feature_view.cuda())
        centers = clustering_model.cluster_centers_.cpu().numpy()  # [C, D]

        view_pred = view_pred.cpu().numpy()

        view_pred_aligned, centers_aligned = match_labels_and_reorder_centers(
            labels_all.numpy(), view_pred, centers
        )

        view_preds_allp.append(view_pred_aligned)
        view_centers.append(centers_aligned)


        view_nmi, view_ari, view_f, view_acc = utils.evaluate(labels_all.numpy(), view_pred_aligned)
        view_silhouette = silhouette_score(feature_view, view_pred)

        print(f"[deep feature view {view_id}] "
              f"NMI: {view_nmi:.4f}, ARI: {view_ari:.4f}, F: {view_f:.4f}, "
              f"ACC: {view_acc:.4f}, Silhouette: {view_silhouette:.4f}")

    for view_id, feature_view in enumerate(features_all_ori):
        feature_view = torch.nn.functional.normalize(feature_view, dim=-1)

        clustering_model = torch_clustering.PyTorchKMeans(
            init='k-means++',
            max_iter=300,
            tol=1e-4,
            metric='cosine',
            distributed=True,
            random_state=0,
            n_clusters=args.n_classes,
            verbose=False
        )

        view_pred = clustering_model.fit_predict(feature_view.cuda())
        centers = clustering_model.cluster_centers_.cpu().numpy()  # [C, D]

        view_pred = view_pred.cpu().numpy()

        view_pred_aligned, centers_aligned = match_labels_and_reorder_centers(
            labels_all.numpy(), view_pred, centers
        )

        view_preds_all.append(view_pred_aligned)
        view_centers.append(centers_aligned)


        view_nmi, view_ari, view_f, view_acc = utils.evaluate(labels_all.numpy(), view_pred_aligned)
        view_silhouette = silhouette_score(feature_view, view_pred)

        print(f"[shallow feature view {view_id}] "
              f"NMI: {view_nmi:.4f}, ARI: {view_ari:.4f}, F: {view_f:.4f}, "
              f"ACC: {view_acc:.4f}, Silhouette: {view_silhouette:.4f}")


    return result, kmeans_label_aligned, view_preds_all, true_labels, view_centers


def evaluate_meta(model: torch.nn.Module, data_loader_test: Iterable,
                  device: torch.device, epoch: int, args=None):
    model.eval()
    extracter = model.extract_feature_meta
    all_features = []
    all_labels = []
    all_indexs = []

    print("Fusion...")

    with torch.no_grad():
        for indexs, samples, mask, labels in data_loader_test:
            indexs = indexs.cpu()
            all_indexs.append(indexs)
            all_labels.append(labels.cpu())
            for i in range(args.n_views):
                samples[i] = samples[i].to(device, non_blocking=True)
            fused_features = extracter(samples, mask)  # shape: [B, D]

            all_features.append(fused_features.cpu())
    indexs_all = torch.cat(all_indexs, dim=0)
    labels_all = torch.cat(all_labels, dim=0)
    features_all = torch.cat(all_features, dim=0)  # shape: [N, D]


    sorted_idx = indexs_all.argsort()
    labels_all = labels_all[sorted_idx]
    features_all = features_all[sorted_idx]


    features_cat = torch.nn.functional.normalize(features_all, dim=-1)

    #
    kwargs = {
        'metric': 'cosine',
        'distributed': True,
        'random_state': 0,
        'n_clusters': args.n_classes,
        'verbose': False
    }

    clustering_model = torch_clustering.PyTorchKMeans(init='k-means++', max_iter=300, tol=1e-4, **kwargs)

    kmeans_label = clustering_model.fit_predict(features_cat.cuda()).cpu().numpy()

    kmeans_label_aligned = match_labels(labels_all.numpy(), kmeans_label)
    cluster_centers = clustering_model.cluster_centers_
    nmi, ari, f, acc = utils.evaluate(labels_all.numpy(), kmeans_label_aligned)
    from sklearn.metrics import silhouette_score
    silhouette_pred = silhouette_score(features_cat, kmeans_label)
    result = {'nmi': nmi, 'ari': ari, 'f': f, 'acc': acc,'sc': silhouette_pred}
    print("Result:", result)

    return result, kmeans_label_aligned,cluster_centers,features_cat

def match_labels(y_true, y_pred, num_classes=None):

    if num_classes is None:
        num_classes = max(y_true.max(), y_pred.max()) + 1


    cost_matrix = np.zeros((num_classes, num_classes), dtype=np.int64)
    for i in range(len(y_true)):
        cost_matrix[y_true[i], y_pred[i]] += 1


    row_ind, col_ind = linear_sum_assignment(cost_matrix.max() - cost_matrix)

    label_mapping = {col: row for row, col in zip(row_ind, col_ind)}


    aligned_preds = np.vectorize(label_mapping.get)(y_pred)

    return aligned_preds

def match_labels_and_reorder_centers(y_true, y_pred, centers):

    num_classes = max(y_true.max(), y_pred.max()) + 1
    cost_matrix = np.zeros((num_classes, num_classes), dtype=np.int64)

    for i in range(len(y_true)):
        cost_matrix[y_true[i], y_pred[i]] += 1

    row_ind, col_ind = linear_sum_assignment(cost_matrix.max() - cost_matrix)
    label_mapping = {col: row for row, col in zip(row_ind, col_ind)}

    aligned_preds = np.vectorize(label_mapping.get)(y_pred)

    aligned_centers = np.zeros_like(centers)
    for pred_label, true_label in label_mapping.items():
        aligned_centers[true_label] = centers[pred_label]

    return aligned_preds, aligned_centers
