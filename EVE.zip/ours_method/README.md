
PyTorch implementation for our mehod


## Requirements

pytorch>=1.13.0 

numpy>=1.23.4

scikit-learn>=0.0.post1

munkres>=1.1.4

## Training

The hyper-parameters, the training options are defined in the configure file.

## Training all datasets
for dataset in Scene15 Scene15-3v Caltech5v-7 LandUse21 CCV; do     python main_train.py --config_file=config/${dataset}.yaml; done


## Training Scene15-3V or Caltech-3V

python main_train.py --config_file=config/Scene15-3v.yaml

python main_train.py --config_file=config/Caltech5v-7.yaml



